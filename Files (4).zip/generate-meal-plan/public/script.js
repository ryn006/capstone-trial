document.getElementById('meal-form').addEventListener('submit', async function(event) {
    event.preventDefault();
    const formData = new FormData(document.getElementById('meal-form'));
    const targetCalories = formData.get('targetCalories');
    const timeFrame = formData.get('timeFrame');
    const diet = formData.get('diet');
    const exclude = formData.get('exclude');

    try {
        const response = await fetch(`/generate-meal-plan?targetCalories=${targetCalories}&timeFrame=${timeFrame}&diet=${diet}&exclude=${exclude}`);
        const data = await response.json();
        displayMealPlan(data);
    } catch (error) {
        console.error('Error fetching meal plan:', error);
    }
});

function displayMealPlan(data) {
    const mealResult = document.getElementById('meal');
    mealResult.innerHTML = '';

    data.meals.forEach(meal => {
        const mealItem = document.createElement('div');
        mealItem.classList.add('meal-item');

        const mealImg = document.createElement('div');
        mealImg.classList.add('meal-img');
        mealImg.innerHTML = `<img src="${meal.image}" alt="${meal.title}">`;

        const mealName = document.createElement('div');
        mealName.classList.add('meal-name');
        mealName.innerHTML = `<h3>${meal.title}</h3>`;

        const recipeBtn = document.createElement('a');
        recipeBtn.classList.add('recipe-btn');
        recipeBtn.setAttribute('href', meal.sourceUrl);
        recipeBtn.setAttribute('target', '_blank');
        recipeBtn.textContent = 'View Recipe';

        mealItem.appendChild(mealImg);
        mealItem.appendChild(mealName);
        mealItem.appendChild(recipeBtn);

        mealResult.appendChild(mealItem);
    });
}