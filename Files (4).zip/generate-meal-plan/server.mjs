import express from 'express';
import fetch from 'node-fetch';

const app = express();
const PORT = process.env.PORT || 5000;
const API_KEY = '081f65d876014893a361ead6aac1cfe8'; // Replace 'YOUR_API_KEY' with your actual API key

app.use(express.static('public'));

app.get('/generate-meal-plan', async (req, res) => {
    const targetCalories = req.query.targetCalories;
    try {
        const response = await fetch(`https://api.spoonacular.com/mealplanner/generate?timeFrame=day&targetCalories=${targetCalories}&apiKey=${API_KEY}`);
        const data = await response.json();
        res.json(data);
    } catch (error) {
        console.error('Error fetching meal plan:', error);
        res.status(500).json({ error: 'An error occurred while fetching the meal plan' });
    }
});

app.listen(PORT, () => console.log(`Server is running on port ${PORT}`));